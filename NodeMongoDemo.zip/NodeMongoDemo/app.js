const express = require('express')
const hbs = require('hbs')




const app = express();
app.set('view engine','hbs');
hbs.registerPartials(__dirname +'/views/partials')

var MongoClient = require('mongodb').MongoClient;
var url = 'mongodb+srv://tommy:112233445566@cluster0.lkrga.mongodb.net/test';
app.get('/',async (req,res)=>{
    let client= await MongoClient.connect(url);  
    let dbo = client.db("ProductDB2");  
    let results = await dbo.collection("products").find({}).toArray();
    res.render('index',{model:results})
})
app.get('/insert',(req,res)=>{
    res.render('newProduct');
})

var bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({ extended: false }));

app.post('/doInsert',async (req,res)=>{
    let nameInput = req.body.txtName;
    let priceInput = req.body.txtPrice;
    
    let client= await MongoClient.connect(url);  
    let dbo = client.db("ProductDB2"); 
    let newProduct = {productName : nameInput, price:priceInput};
    await dbo.collection("products").insertOne(newProduct);
   
    res.redirect('/');
})

var PORT = process.env.PORT || 3000
app.listen(PORT)
console.log("Server is running!")